import uno
# get the uno component context from the PyUNO runtime
localContext = uno.getComponentContext()

# create the UnoUrlResolver
resolver = localContext.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", localContext)

# connect to the running office
ctx = resolver.resolve("uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
smgr = ctx.ServiceManager

# get the central desktop object
DESKTOP =smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
###################################
from bs4 import BeautifulSoup

page = open('C:/pycon/T2.split/ex2.usingBS4/29592.github.io-master/index.html', 'rt', encoding='utf-8').read()
soup = BeautifulSoup(page, 'html.parser')
print(soup.prettify())
print(soup.find_all('tr','tr_blue4'))
res = soup.find_all('tr','tr_blue4')
nlist = []
for n in res:
    nlist.append((n.get_text().split('\n'),))

###################################
#calling to calc model
turl = 'file:///C:/pycon/T2.split/ex2.usingBS4/환자식.ods'
tmodel = DESKTOP.loadComponentFromURL(turl,"_blank",0,() )
tsheet = tmodel.Sheets.getByIndex(0)

#paste to file
for i in range(0,len(nlist)):
    for j in range(0,len(nlist[i][0])):
        tsheet.getCellByPosition(i,j).String = nlist[i][0][j]




#save
from com.sun.star.beans import PropertyValue
args = (PropertyValue('FilterName', 0, 'MS Excel 97', 0),)
tmodel.storeAsURL(turl, args)
