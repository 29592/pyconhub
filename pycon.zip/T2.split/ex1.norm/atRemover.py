import uno
# get the uno component context from the PyUNO runtime
localContext = uno.getComponentContext()

# create the UnoUrlResolver
resolver = localContext.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", localContext)

# connect to the running office
ctx = resolver.resolve("uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
smgr = ctx.ServiceManager

# get the central desktop object
DESKTOP =smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
###################################
# import root folder path
rfolder = 'C:/pycon/T2.split/ex1.norm/'

# calling to calc model
furl = 'file:///'+rfolder+'고객email.ods'
turl = 'file:///'+rfolder+'고객.ods'
fmodel = DESKTOP.loadComponentFromURL(furl,"_blank",0,() )
tmodel = DESKTOP.loadComponentFromURL(turl,"_blank",0,() )

fsheet = fmodel.Sheets.getByIndex(0)
tsheet = tmodel.Sheets.getByIndex(0)

# copy Start
cursor = fsheet.createCursor()
# goto the last used cell
cursor.gotoEndOfUsedArea(True)
# grab that positions "coordinates"
faddress = cursor.RangeAddress
#fendrow = faddress.EndRow ?????? 

fcellname = 'B1:B'+str(fendrow)
fRange = fsheet.getCellRangeByName(fcellname)
fArray = fRange.getDataArray()
########################################
i=0
flist = []
while i < fendrow:
 # use split!
 i+=1

#paste to file
tcellname = 'B1:B'+str(fendrow)
tRange = tsheet.getCellRangeByName(tcellname)
tRange.setDataArray(tuple(flist))

#save
from com.sun.star.beans import PropertyValue
args = (PropertyValue('FilterName', 0, 'MS Excel 97', 0),)
tmodel.storeAsURL(turl, args)
