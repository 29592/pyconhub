def getLastActiveCell(sheet):
    """returns the last used column and row of the provided sheet 
    (ie the last cell in the range containing something other than '')"""
    #create a cursor for the whole sheet using OO interface XSheetCellRange 
    cursor = sheet.createCursor()
    #goto the last used cell
    cursor.gotoEndOfUsedArea(True)
    #grab that positions "coordinates"
    address = cursor.RangeAddress
    endcol = address.EndColumn
    endrow = address.EndRow
    #and pass them back
    return endcol,endrow
    


def colorChange(*args):
#get the doc from the scripting context which is made available to all scripts
    DESKTOP = XSCRIPTCONTEXT.getDesktop()
    model = DESKTOP.getCurrentComponent()
#check whether there's already an opened document. Otherwise, create a new one
    lastCell = [1,2]
    if not hasattr(model, "Sheets"):
        model = DESKTOP.loadComponentFromURL("private:factory/scalc","_blank", 0, () )
    active_sheet = model.Sheets.getByIndex(0)
    lastCell = getLastActiveCell(active_sheet)
    col = 0
    i = 0
    while col <= lastCell[0]:
        row = 0
        while row <= lastCell[1]:
            cell1 = active_sheet.getCellByPosition(col,row)
            cell1.CellBackColor = ~cell1.CellBackColor + 0xFFFFFF
            row += 1
        col += 1

# lists the scripts, that shall be visible inside OOo. Can be omitted, if
# all functions shall be visible, however here getNewString shall be suppressed
g_exportedScripts = colorChange,
