import uno
# get the uno component context from the PyUNO runtime
localContext = uno.getComponentContext()

# create the UnoUrlResolver
resolver = localContext.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", localContext)

# connect to the running office
ctx = resolver.resolve("uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
smgr = ctx.ServiceManager

# get the central desktop object
DESKTOP =smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
###################################
#import root folder path
rfolder = 'C:/pycon/T1.integrate/ex1.calcToText/'
#------------------------------------------------

#from_file name
ffilename = '1907+세무보고.ods'
tfilename = '파이세무서_양식.ods'

#calling original model
urladress = 'file:///'+rfolder+ffilename
fmodel = DESKTOP.loadComponentFromURL(urladress,"_blank",0,() )   
urladress = 'file:///'+rfolder+tfilename
tmodel = DESKTOP.loadComponentFromURL(urladress,"_blank",0,() )   
fsheet = fmodel.Sheets.getByIndex(0)
tsheet = tmodel.Sheets.getByIndex(0)


#call each Cell
fRange = fsheet.getCellRangeByName('C7')
tRange = tsheet.getCellRangeByName('E11')
tRange.Value = fRange.Value

fRange = fsheet.getCellRangeByName('G7')
tRange = tsheet.getCellRangeByName('F11')
tRange.Value = fRange.Value

fRange = fsheet.getCellRangeByName('J7')
tRange = tsheet.getCellRangeByName('G11')
tRange.Value = fRange.Value
#call value list
flist =[]
flist.extend([fsheet.getCellRangeByName('C13').Value])
flist.extend([fsheet.getCellRangeByName('G13').Value])
flist.extend([fsheet.getCellRangeByName('J13').Value])
flist.extend([fsheet.getCellRangeByName('C16').Value])
flist.extend([fsheet.getCellRangeByName('G16').Value])
flist.extend([fsheet.getCellRangeByName('J16').Value])
tlist =[]
tlist.extend([tsheet.getCellRangeByName('E12')])
tlist.extend([tsheet.getCellRangeByName('F12')])
tlist.extend([tsheet.getCellRangeByName('G12')])

tlist.pop().Value = flist.pop()
tlist.pop().Value = flist.pop()
while tlist:
 tlist.pop().Value = flist.pop()

tcell = tsheet.getCellByPosition( 4, 15)
tcell.Value = flist.pop()

tsheet.getCellByPosition( 5, 15).Value = flist.pop()
tsheet.getCellByPosition( 6, 15).Value = flist.pop()

# tmodel.storeToURL(turl) # tmodel.storeToURL( turl, Array( makePropertyValue( "FilterName", "HTML (StarCalc)" ) ) ) # model.storeToURL(turl,tuple([PropertyValue('FilterName',0,'calc_pdf_Export',0)])) # model.storeAsURL(turl,tuple()) 
from com.sun.star.beans import PropertyValue
args = (PropertyValue('FilterName', 0, 'MS Excel 97', 0),)
tmodel.storeAsURL(turl, args)
