import uno
# get the uno component context from the PyUNO runtime
localContext = uno.getComponentContext()

# create the UnoUrlResolver
resolver = localContext.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", localContext)

# connect to the running office
ctx = resolver.resolve("uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
smgr = ctx.ServiceManager

# get the central desktop object
DESKTOP =smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
###################################
#import root folder path
rfolder = 'C:/pycon/T1.integrate/ex2.pivot/'
# rfolder = 'C:/Users/kyoohoA/Desktop/pycon/T1.integrate/ex.pivot/'

#from_file name
filename = '보험팀.ods'

#calling original model
urladress = 'file:///'+rfolder+filename
fmodel = DESKTOP.loadComponentFromURL(urladress,"_blank",0,() )   
fsheet = fmodel.Sheets.getByIndex(0)
#cursor made
cursor = fsheet.createCursor()
#goto the last used cell
cursor.gotoEndOfUsedArea(True)
#grab that positions "coordinates"
faddress = cursor.RangeAddress
fendrow = faddress.EndRow
fcellname = 'A2:E'+str(fendrow)
fRange = fsheet.getCellRangeByName(fcellname)
fArray = fRange.getDataArray()

#calling to calc model
turl = 'file:///' + rfolder + '개별.ods'
tmodel = DESKTOP.getCurrentComponent()
tmodel = DESKTOP.loadComponentFromURL(turl,"_blank",0,() )
tsheet = tmodel.Sheets.getByIndex(0)

#cursor made
cursor = tsheet.createCursor()
#goto the last used cell
cursor.gotoEndOfUsedArea(True)
#grab that positions "coordinates"
taddress = cursor.RangeAddress
tendrow = taddress.EndRow

tendrow += 1
tcellname = 'A'+str(tendrow)+':E'+str(tendrow+fendrow-2)
tendrow += fendrow -2
tRange = tsheet.getCellRangeByName(tcellname)
tRange.setDataArray(fArray)
#
# tmodel.storeToURL(turl) # tmodel.storeToURL( turl, Array( makePropertyValue( "FilterName", "HTML (StarCalc)" ) ) ) # model.storeToURL(turl,tuple([PropertyValue('FilterName',0,'calc_pdf_Export',0)])) # model.storeAsURL(turl,tuple()) 
from com.sun.star.beans import PropertyValue
args = (PropertyValue('FilterName', 0, 'MS Excel 97', 0),)
tmodel.storeAsURL(turl, args)
