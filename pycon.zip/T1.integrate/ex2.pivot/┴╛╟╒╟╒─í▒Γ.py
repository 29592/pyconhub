import uno
# get the uno component context from the PyUNO runtime
localContext = uno.getComponentContext()

# create the UnoUrlResolver
resolver = localContext.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", localContext)

# connect to the running office
ctx = resolver.resolve("uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
smgr = ctx.ServiceManager

# get the central desktop object
DESKTOP =smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
###################################
#import root folder path
rfolder = 'C:/pycon/T1.integrate/ex2.pivot/'

#calling to calc model
turl = 'file:///'+rfolder+'종합.ods'
tmodel = DESKTOP.getCurrentComponent()
tmodel = DESKTOP.loadComponentFromURL(turl,"_blank",0,() )
if not hasattr(tmodel, "Sheets"):
 tmodel = DESKTOP.loadComponentFromURL("private:factory/scalc","_blank", 0, () )
tsheet = tmodel.Sheets.getByIndex(0)
tendrow = 1

#loop Start

#################################
#end of loop